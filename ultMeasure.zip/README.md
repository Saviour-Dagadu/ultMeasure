# Savitech Web Project
Introduction : 

Savitech is a software developing and research company with over 9 years experience in data collection and research.

**Link to project:** hhttps://savitech.netlify.app/

![alt tag](https://i.postimg.cc/BtW3M85y/Screenshot-133.png)


## How It's Made:
HTML Code: HTML code is used to design the basic structure of the project. 

JavaScript Code: The JavaScript code contains the functionality. 


**Tech used:** HTML, CSS, JavaScript

Here's where you can go to town on how you actually built this thing. Write as much as you can here, it's totally fine if it's not too much just make sure you write *something*. If you don't have too much experience on your resume working on the front end that's totally fine. This is where you can really show off your passion and make up for that ten fold.








